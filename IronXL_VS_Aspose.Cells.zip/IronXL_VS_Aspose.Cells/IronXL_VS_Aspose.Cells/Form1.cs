﻿using Aspose.Cells;
using System;
using System.Windows.Forms;
using IronXL;

namespace IronXL_VS_Aspose.Cells
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var book = new Aspose.Cells.Workbook();
            var sheet = book.Worksheets[0];
            var cells = sheet.Cells;
            cells["A1"].Value = "Hello World from Aspose.Cells";
            book.Save("Aspose.Cells_Output.xlsx", SaveFormat.Xlsx);
        }

        private void button2_Click(object sender, EventArgs e)
        {

            WorkBook workbook = WorkBook.Create(ExcelFileFormat.XLSX);
            var sheet = workbook.CreateWorkSheet("IronXL Worksheet");
            sheet["A1"].Value = "Hello World from IronXL;";
            workbook.SaveAs("IronXL_Output.xlsx");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var workbook = new Aspose.Cells.Workbook("Aspose.Cells_Output.xlsx");
            workbook.Save("Aspose.Cells_Output.pdf", Aspose.Cells.SaveFormat.Pdf);
            workbook.Save("Aspose.Cells_Output.html", Aspose.Cells.SaveFormat.Html);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WorkBook workbook = WorkBook.Load("IronXL_Output.xlsx");
            workbook.SaveAsJson("IronXL_Output.json");
            workbook.SaveAsXml("IronXL_Output.xml");
        }
    }
}
